const arrayEventos = [
  {
    tituloEvento: "Festival do Vinho de São Roque (SP)",
    imgEvento:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-AODwy1OJl_HRtopF81h0RHwt1r91fusuUA&s",
    textoEvento:"Degustar uma ampla variedade de vinhos locais, desde os tradicionais tintos e brancos até espumantes e vinhos de sobremesa.",
    dataEvento:"Data: 20/12 - 17h 30 min",
    localEvento:"Local: Cidade de São Roque",
    linkEvento:""
  },
  {
    tituloEvento: "Festival do Vinho de Bento Gonçalves (RS)",
    imgEvento:"https://www.rbsdirect.com.br/filestore/2/3/2/1/5/9/1_6a42d82cba3fdff/1951232_9480beaea33b35f.jpg?w=700",
    textoEvento:"Festival do Vinho de Bento Gonçalves (RS) – Realizado na capital brasileira do vinho, é um evento que celebra a cultura vinícola da região, com degustações, gastronomia típica e atrações culturais.",
    dataEvento:"Data: 15/08 - De 10h às 22h.",
    localEvento:"Local: Bento Gonçalves, Rio Grande do Sul",
    linkEvento:""
  },{
    tituloEvento: "Festival do Vinho de Bento Gonçalves (RS)",
    imgEvento:"https://www.rbsdirect.com.br/filestore/2/3/2/1/5/9/1_6a42d82cba3fdff/1951232_9480beaea33b35f.jpg?w=700",
    textoEvento:"Festival do Vinho de Bento Gonçalves (RS) – Realizado na capital brasileira do vinho, é um evento que celebra a cultura vinícola da região, com degustações, gastronomia típica e atrações culturais.",
    dataEvento:"Data: 15/08 - De 10h às 22h.",
    localEvento:"Local: Bento Gonçalves, Rio Grande do Sul",
    linkEvento:""
  },
]


for(let i = 0; i < arrayEventos.length; i++){

// console.log(arrayEventos)

  const article = document.createElement('article')

  article.innerHTML = `
   <h3>${arrayEventos[i].tituloEvento}</h3>
        <div class="top">
          <img src=${arrayEventos[i].imgEvento} alt="Imagem do evento">
          <p>${arrayEventos[i].textoEvento}</p>
        </div>
        <span><strong>${arrayEventos[i].localEvento}</strong></span>
        <span><strong>${arrayEventos[i].dataEvento}</strong></span>
        <a href=${arrayEventos[i].linkEvento}>Saiba Mais --></a>
  `

  const section = document.querySelector('section')

  section.appendChild(article)
}